package com.mindgate.pojo;

public class B extends A{
	public B()
	{
		System.out.println("Hello");
	}
	
	public B(int x)
	{super(x);
		System.out.println("Hello"+x);
	}
	
	
//	public B(int x)
//	{
//		System.out.println("Hello"+x);
//	}
//	
	
	
	
	
	
//public B()
//{
//	System.out.println("Hello");
//}
	
	
	
//	@Override
//	public void display() {
//		// TODO Auto-generated method stub
//	
//		super.display();
//		System.out.println("Hello");
//	}
//public void print()
//{
//	System.out.println("in class B print()");
//	A a=new A();
//	a.display();
//}
}
