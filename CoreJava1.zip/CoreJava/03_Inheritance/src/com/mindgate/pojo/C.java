package com.mindgate.pojo;

public class C {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		B b=new B(10) ;
		
		
		
		//B b=new B();
		//b.display();
	
	}

}
