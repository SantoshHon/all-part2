package com.mindgate.pojo;

public class A {
	public A()
	{
		System.out.println("hii");
	}
	public A(int x)
	{
		System.out.println("Hello"+x);
	}
	
//	public A(){
//		System.out.println("Hii");
//		
//	}
//	public A(int x)
//	{
//		System.out.println("Hii"+x);
//	}
//	public A()
//	{
//		System.out.println("Hi");
//	}
//	public void display()
//	{
//		System.out.println("hi");
//	}

}
