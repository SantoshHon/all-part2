package calender;

import java.util.Scanner;

public class practis {
	
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		

        int d=scanner.nextInt();
        int m=scanner.nextInt();
        int y=scanner.nextInt();
        int month1=0;

        
      if(m==1||m==10)
      {
          month1=0;
      }
      else if(m==2||m==3||m==11)
      {
          month1=3;
          
      }
      else if(m==4||m==7)
      {
          month1=6;
      }
      else if(m==5)
      {
          month1=1;
      }
      else if(m==6)
      {
          month1=4;
      }
      else if(m==8)
      {
          month1=2;
      }
      else if(m==9||m==12)
      {
          month1=5;
      }
      int year1=y%100;
    int  year2=year1/4;
    int b=0;
    
    if(y%4==0&&y%100!=0)
    {
        b=1;
    }
    else if(y%400==0)
    {
        b=1;
    }
    else
    {
        b=0;
    }
    int sum=(year1+year2+month1+d+6);
    
    
    System.out.println(sum);
    
    
    int day2=sum%7;
    int day1=0;
    if((b==1)&&(m==1||m==2))
    {
     day1=day2-b;
    }
    else
    {
        day1=day2;
    }
    
    
        
    
    if(day1==0)
    {
        System.out.println("SUNDAY");
      //  return "SUNDAY";
    }
    else if(day1==1)
    {
        System.out.println("MONDAY");
        //return "MONDAY";
    }
    else if(day1==2)
    {
       System.out.println("TUESDAY");
       // return "TUESDAY";
    }
    else if(day1==3)
    {
        System.out.println("WEDNESDAY");
      //  return "WEDNESDAY";
    }
    else if(day1==4)
    {
        System.out.println("THURSDAY");
       // return "THURSDAY";
    }
    else if(day1==5)
    {
        System.out.println("FRIDAY");
       // return "FRIDAY";
    }
    
    else
    {
        System.out.println("SATURDAY");
       // return "SATURDAY";
    }




	}

}
