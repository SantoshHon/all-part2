package com.mindgate.service;

public interface Notification {
	void sendNotification(String to,String message);

}
