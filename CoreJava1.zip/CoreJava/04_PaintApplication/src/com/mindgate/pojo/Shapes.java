package com.mindgate.pojo;

public class Shapes {
	public void draw()
	{
		System.out.println("This is draw");
	}

}
