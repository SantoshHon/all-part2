package com.mindgate.pojo;

public class Square extends Shapes {
	public void draw() {
		System.out.println("drawing square");
	}
}
