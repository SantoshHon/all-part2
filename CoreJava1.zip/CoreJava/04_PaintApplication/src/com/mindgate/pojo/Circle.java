package com.mindgate.pojo;

public class Circle extends Shapes {


public void draw() {
	System.out.println("drawing circle");
}
}
