package com.mindgate.pojo;

public class Triangle extends Shapes{
	public void draw() {
		System.out.println("drawing triangle");
	}

}
