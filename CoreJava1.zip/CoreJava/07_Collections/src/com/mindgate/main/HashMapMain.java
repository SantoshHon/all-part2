package com.mindgate.main;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class HashMapMain {

	public static void main(String[] args) {

		Map<Integer,String>employeeMap=new HashMap<Integer, String>();
		employeeMap.put(101, "Santosh");
		employeeMap.put(1023, "Sagar");
		employeeMap.put(102, "Parag");
		employeeMap.put(1044, "Pravin");
		System.out.println(employeeMap);
		
		
		

		
	}

}
