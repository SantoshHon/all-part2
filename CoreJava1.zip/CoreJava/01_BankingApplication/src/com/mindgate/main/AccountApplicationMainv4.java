package com.mindgate.main;

import com.mindgate.pojo.Savings;

public class AccountApplicationMainv4 {

	public static void main(String[] args) {
      Savings savings=new Savings(101,"Santosh", 3000,false);

	}

}
